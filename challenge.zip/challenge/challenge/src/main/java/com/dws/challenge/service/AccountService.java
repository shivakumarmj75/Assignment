package com.dws.challenge.service;

public interface AccountService {
    Account getAccountDetails(Integer acctId);
    boolean transferAmount(AmtTransfer amtTransfer);
}