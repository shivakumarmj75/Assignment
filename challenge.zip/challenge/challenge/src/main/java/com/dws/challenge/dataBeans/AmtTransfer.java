package com.dws.challenge.dataBeans;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AmtTransfer {
    private Integer fromAcctId;
    private Integer toAcctId;
    private BigDecimal amount;
    private String transferType;
}