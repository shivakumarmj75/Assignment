package com.dws.challenge.service.impl;

@Service
public class AccountServiceImpl implements AccountService{

    public Account getAccountDetails(Integer acctId) {
        return null;
    }

    public boolean transferAmount(AmtTransfer amtTransfer){
        /*
        Please perform the below operations as part of single transaction:
        Update the balances in from and to accounts
        Add the transaction description in both the accounts
        Invoke the NotificationService to inform the concerned account holders
         */
        return true;
    }
}