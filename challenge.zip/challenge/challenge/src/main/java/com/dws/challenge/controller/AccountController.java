package com.dws.challenge.controller;

@RestController
@RequestMapping("/Account")
public class AccountController {

    private Integer acctMinBalance = 1000;

    @Autowired
    private AccountService accountService;

    @PostMapping("/transferAmt")
    public ResponseEntity<?> transferAmt(@RequestBody AmtTransfer amtTransfer) {
        if(amtTransfer.getAmount() < 0){
            return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).build();
        }

        Account fromAccount = accountService.getAccountDetails(amtTransfer.getFromAcctId());
        BigDecimal totAmt = acctMinBalance + amtTransfer.getAmount();
        if(fromAccount.getBalance() < totAmt){
            return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).build();
        }
        boolean transferStatus = accountService.transferAmount(amtTransfer);
        if(transferStatus){
            return ResponseEntity.status(HttpStatus.OK).build();
        }
    }
}