package com.dws.challenge.dataBeans;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Account {
    private Integer accountId;
    private String accountHolder;
    private String status;
    private BigDecimal balance;
    private String txnInfo;
}